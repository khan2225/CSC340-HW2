package com.example.CSC340HW2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Csc340Hw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Csc340Hw2Application.class, args);
	}
  public static void ravenPrice() {
        try {
            String url = "https://wft-geo-db.p.rapidapi.com/v1/geo/countries?namePrefix=U";
            RestTemplate restTemplate = new RestTemplate();
            ObjectMapper mapper = new ObjectMapper();

            String name = restTemplate.getForObject(url, String.class);
            JsonNode root = mapper.readTree(name);

            //gets coin name
            String counName = root.findValue("name").asText();
            //gets coin value in USD
            //double coinPrice = root.findValue("price_usd").asDouble();
            //print vals
            System.out.println("Country Name: " + counName);
           // System.out.println("Price: " + coinPrice);

        } catch (JsonProcessingException ex) {
           System.out.println("error in finding country with name prefix");
        }
    }
}
