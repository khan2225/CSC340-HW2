package com.example.CSC340HW2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csc340Hw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
