package com.example.CSC340HW2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Csc340Hw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Csc340Hw2Application.class, args);
	}

}
